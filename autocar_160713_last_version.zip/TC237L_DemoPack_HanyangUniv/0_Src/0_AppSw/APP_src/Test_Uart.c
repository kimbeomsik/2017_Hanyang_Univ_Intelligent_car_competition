/******************************************************************************
**                                                                           **
** Copyright (C) Infineon Technologies (2013)                                **
**                                                                           **
** All rights reserved.                                                      **
**                                                                           **
** This document contains proprietary information belonging to Infineon      **
** Technologies. Passing on and copying of this document, and communication  **
** of its contents is not permitted without prior written authorization.     **
**                                                                           **
*******************************************************************************
**                                                                           **
**  $FILENAME   : Test_Uart.c $                                              **
**                                                                           **
**  $CC VERSION : \main\16 $                                                 **
**                                                                           **
**  $DATE       : 2013-07-03 $                                               **
**                                                                           **
**  AUTHOR      : DL-AUTOSAR-Engineering                                     **
**                                                                           **
**  VENDOR      : Infineon Technologies                                      **
**                                                                           **
**  DESCRIPTION : This file contains                                         **
**                - sample Demo Application for UART module                  **
**                                                                           **
**  MAY BE CHANGED BY USER [yes/no]: yes                                     **
**                                                                           **
******************************************************************************/
/*******************************************************************************
**                      Includes                                              **
*******************************************************************************/
#include <stdio.h>
#include <Ifx_Types.h>
#include <Asclin/Asc/IfxAsclin_Asc.h>
#include "Test_Irq.h"

#define ASC_TX_BUFFER_SIZE 64
#define ASC_RX_BUFFER_SIZE 64
#define UART_BUFFER_DATA_SIZE		10U

//****************************************************************************
// @Typedefs
//****************************************************************************
typedef struct
{
    uint8 tx[ASC_TX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];
    uint8 rx[ASC_RX_BUFFER_SIZE + sizeof(Ifx_Fifo) + 8];
} AppAscBuffer;

/** \brief Asc information */
typedef struct
{
    AppAscBuffer ascBuffer;                     /**< \brief ASC interface buffer */
    struct
    {
        IfxAsclin_Asc asc0;                     /**< \brief ASC interface */
        IfxAsclin_Asc asc1;                     /**< \brief ASC interface */
    }         drivers;

    uint8 Uart_TxData[UART_BUFFER_DATA_SIZE];
    uint8 Uart_RxData[UART_BUFFER_DATA_SIZE];

	uint16	TxComplete		:16;
	uint16	RxComplete		:16;
	uint16	ErComplete		:16;

    Ifx_SizeT count;
} App_AsclinAsc;

/*******************************************************************************
**                      Private Variable Declarations                         **
*******************************************************************************/

App_AsclinAsc AsclinAsc; /**< \brief Demo information */

/*******************************************************************************
**                      Global Function Definitions                           **
*******************************************************************************/
void Uart_Initialization(void);
void Uart_Test(void);
void Uart_Tx(Ifx_SizeT size);
void Uart_Rx(Ifx_SizeT size);
void ClearUartTx(void);
void UartStoreADC(uint16 adc);
void EnterLine();
//******************************************************************************
// @Function	 	void Uart_Initialization(void)
// @Description   	UART initialization for test with StarterKit
// @Returnvalue		None
// @Parameters    	None
//******************************************************************************
void Uart_Initialization(void)
{
	static uint8 i;

	/* disable interrupts */
    boolean              interruptState = IfxCpu_disableInterrupts();
    /* create module config */
    IfxAsclin_Asc_Config Uart_AscLin0;
    IfxAsclin_Asc_initModuleConfig(&Uart_AscLin0, &MODULE_ASCLIN0);

    /* set the desired baudrate */
    Uart_AscLin0.baudrate.prescaler    = 1;
    Uart_AscLin0.baudrate.baudrate     = 38400; /* FDR values will be calculated in initModule */
    Uart_AscLin0.baudrate.oversampling = IfxAsclin_OversamplingFactor_4;

    /* ISR priorities and interrupt target */
    Uart_AscLin0.interrupt.txPriority    = ISR_PRIORITY_ASCLIN0_TX;
    Uart_AscLin0.interrupt.rxPriority    = ISR_PRIORITY_ASCLIN0_RX;
    Uart_AscLin0.interrupt.erPriority    = ISR_PRIORITY_ASCLIN0_ER;
    Uart_AscLin0.interrupt.typeOfService = IfxSrc_Tos_cpu0;

    /* FIFO configuration */
    Uart_AscLin0.txBuffer     = AsclinAsc.ascBuffer.tx;
    Uart_AscLin0.txBufferSize = ASC_TX_BUFFER_SIZE;

    Uart_AscLin0.rxBuffer     = AsclinAsc.ascBuffer.rx;
    Uart_AscLin0.rxBufferSize = ASC_RX_BUFFER_SIZE;

	const IfxAsclin_Asc_Pins pins = {
        NULL,                     IfxPort_InputMode_pullUp,        /* CTS pin not used */
        &IfxAsclin0_RXB_P15_3_IN, IfxPort_InputMode_pullUp,        /* Rx pin */
        NULL,                     IfxPort_OutputMode_pushPull,     /* RTS pin not used */
        &IfxAsclin0_TX_P15_2_OUT, IfxPort_OutputMode_pushPull,     /* Tx pin */
        IfxPort_PadDriver_cmosAutomotiveSpeed1
    };

    for(i=0; i<UART_BUFFER_DATA_SIZE;i++)
		AsclinAsc.Uart_TxData[i] = 'O';
    Uart_AscLin0.pins = &pins;

    /* initialize module */
    IfxAsclin_Asc_initModule(&AsclinAsc.drivers.asc0, &Uart_AscLin0);

    /* enable interrupts again */
    IfxCpu_restoreInterrupts(interruptState);



} /* End of Uart_Initialization */


//******************************************************************************
// @Function	 	void Uart_Test(void)
// @Description   	UART communication test
// @Returnvalue		None
// @Parameters    	None
//******************************************************************************
void Uart_Test(void)
{ 

	static	uint8	i=0;

	    /* Transmit data */
	    AsclinAsc.count = UART_BUFFER_DATA_SIZE;

	    for(i=0; i<UART_BUFFER_DATA_SIZE;i++)
			AsclinAsc.Uart_TxData[i] = 'O';
	    IfxAsclin_Asc_write(&AsclinAsc.drivers.asc0,AsclinAsc.Uart_TxData, &AsclinAsc.count, TIME_INFINITE);

	    /* Receive data */
	    IfxAsclin_Asc_read(&AsclinAsc.drivers.asc0, AsclinAsc.Uart_RxData, &AsclinAsc.count, 0xFF);


//		for(i=0; i<UART_TEST_DATA_SIZE; i++)
//		{
//			AsclinAsc.Uart_TxData[i] = AsclinAsc.Uart_TxData[i]+1;
//		}


}	/* End of Kline_Test */

void Uart_Tx(Ifx_SizeT size)
{
    AsclinAsc.count = size;
    IfxAsclin_Asc_write(&AsclinAsc.drivers.asc0,AsclinAsc.Uart_TxData, &AsclinAsc.count, TIME_INFINITE);
}
void Uart_Rx(Ifx_SizeT size)
{

    AsclinAsc.count = size;
    IfxAsclin_Asc_read(&AsclinAsc.drivers.asc0, AsclinAsc.Uart_RxData, &AsclinAsc.count, 0xFF);
}

// Uart Store Adc information
void ClearUartTx()
{
	AsclinAsc.Uart_TxData[0] = NULL;
}

// Uart Store Adc information
void UartStoreADC(uint16 adc)
{
	int index = 4;
	uint8 data[5];
	data[index] = (uint8)'/'; index--;
	if(adc%10 == 0) data[index] = (uint8)('O');
	else data[index] = (uint8)(adc%10+'0');
	adc = adc / 10; index--;
	if(adc%10 == 0) data[index] = (uint8)('O');
	else data[index] = (uint8)(adc%10+'0');
	adc = adc / 10; index--;

	if(adc%10 == 0) data[index] = (uint8)('O');
	else data[index] = (uint8)(adc%10+'0');
	adc = adc / 10; index--;

	if(adc%10 == 0) data[index] = (uint8)('O');
	else data[index] = (uint8)(adc%10+'0');

	strcat(AsclinAsc.Uart_TxData, data);
	//appendStr(AsclinAsc.Uart_TxData, data, 4);
}

void UartChar(uint8 adc)
{

	if(adc == '0') AsclinAsc.Uart_TxData[0] = (uint8)('O');
	else AsclinAsc.Uart_TxData[0] = (uint8)(adc);

}

void EnterLine()
{
	int index = 0;
	AsclinAsc.Uart_TxData[index] = (uint8)'\r'; index++;
	AsclinAsc.Uart_TxData[index] = (uint8)'\n'; index++;
	Uart_Tx(2);
}

IFX_INTERRUPT(Uart_AscLin0_TxIsr, 0, ISR_PRIORITY_ASCLIN0_TX)
{
    IfxAsclin_Asc_isrTransmit(&AsclinAsc.drivers.asc0);
    AsclinAsc.TxComplete++;
}

/** \} */

/** \name Interrupts for Receive
 * \{ */

IFX_INTERRUPT(Uart_AscLin0_RxIsr, 0, ISR_PRIORITY_ASCLIN0_RX)
{
    IfxAsclin_Asc_isrReceive(&AsclinAsc.drivers.asc0);
    AsclinAsc.RxComplete++;
}

/** \} */

/** \name Interrupts for Error
 * \{ */

IFX_INTERRUPT(Uart_AscLin0_ErIsr, 0, ISR_PRIORITY_ASCLIN0_ER)
{
    IfxAsclin_Asc_isrError(&AsclinAsc.drivers.asc0);
    AsclinAsc.ErComplete++;

}
