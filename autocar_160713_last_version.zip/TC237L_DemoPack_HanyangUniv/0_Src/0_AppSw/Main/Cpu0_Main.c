/**
 * file Cpu0_Main.c
 * \brief Main function definition for Cpu core 0 .
 *
 * \copyright Copyright (c) 2012 Infineon Technologies AG. All rights reserved.
 *
 *
 *
 *                                 IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 */

#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "Tricore/Cpu/Std/IfxCpu_Intrinsics.h"
#include "Tricore/Scu/Std/IfxScuWdt.h"
#include <Stm/Std/IfxStm.h>
#include <Port/Std/IfxPort.h>
#include "Test_Irq.h"
#include "Test_ModuleInit.h"


#include "Test_Pwm.h"
#include "Test_Adc.h"
#include "Test_Can.h"
#include "TLF35584Demo.h"

#include <string.h>

#define LEFT2			0
#define LEFT1			1
#define LEFT          	2 //((uint16)0x270U)
#define CENTER          3 //((uint16)0x210U)
#define RIGHT           4 //((uint16)0x2D0U)
#define RIGHT1			5
#define RIGHT2			6

#define RUN_IDE			0
#define RUN_START		1
#define RUN_LIMIT_START	2
#define RUN_RESUME		3
#define RUN_STOP		4

#define AVOID_IDLE		0
#define AVOID_RUN1		1
#define AVOID_MOVE_L	2
#define AVOID_RUN2		3
#define AVOID_MOVE_R	4
#define AVOID_RECOVER_R 5
#define AVOID_RECOVER_RUN 6

#define IDLE			0
#define CALIB_START		1
#define CALIB_STOP		2
#define RUN				3

#define	HIGH			1
#define LOW				0

#define CAMERA_INDEX	2
#define CAM_PIXEL		128
#define CAM1 			0
#define CAM2			1

#define CAM_RAW_DEBUG	0
#define CAM_1_DEBUG		0
#define CAM_CALIB_DEBUG 0
#define CAM_RAW_LINE_DEBUG	0
#define CAM_ALL_DEBUG	0
#define MODE_DEBUG		0
#define DISTANCE_DEBUG  0

#define CAM_THRESHOLD   60

#define FRONT			1
#define BACK			0

#define LINE_COUNT		9

#define INTERVAL		7
#define OFFSET_INTERVAL 4

#define FRONT_D_1		0
#define FRONT_D_2		1
#define RIGHT_D			2

#define AVOID_MAX		1200
#define AVOID_SPEED		550

#define AVOID_FRONT_DISTANCE	1050
#define AVOID_RIGHT_DISTANCE	1800

extern void ClearUartTx(void);
extern void Uart_Tx(Ifx_SizeT size);
extern void Uart_Rx(Ifx_SizeT size);
extern void UartStoreADC(unsigned int adc);
extern void EnterLine();
extern void UartChar(uint8 adc);

volatile uint8 encoder_before = 1;
volatile uint16 inittest = 0;
volatile uint16 initStartCount = 0;
volatile int CAM_CHECK = CAM1;

volatile uint32 RUNNING_STATUS = RUN_IDE;

volatile uint32 Weight_Total = 0, Sum_Total = 0;
volatile uint32 Sum_Total_1 = 0, Sum_Total_2 = 0;

typedef struct camera_struct
{
	volatile uint16 CAM_Raw[128];
	volatile uint16 CAM_Cali[128];

}Cam;

volatile Cam CAM_Data[CAMERA_INDEX];
volatile uint8 CAM_No = 0;

volatile uint32 CAM_CT_RESULT[CAMERA_INDEX][50] = {{0},};

//volatile uint16 initCLKCount = 0;
volatile int initSICount = 0;
volatile uint16 Camera_flag = 0;

volatile uint32 test_count = 0;
volatile uint32 CLKCount = 0;
volatile uint32 Count1ms = 0;
volatile uint32 Count100us = 0;

volatile uint16 LINE_NUM = 250;

volatile uint16 CAM1_RAW_LINE = 250; // straight
volatile uint16 CAM2_RAW_LINE = 250; // straight

volatile int CAM1_LINE = 4; // straight
volatile int CAM2_LINE = 4; // straight

volatile int LINE_STATUS = CENTER;

volatile uint16 SWITCH_FLAG[3] = {0,0,0};
volatile uint16 SWITCH_FLAG_BEFORE[3] = {0,0,0};
volatile uint16 SWITCH_CNT[3] = {0,0,0};

volatile uint16 SERVO_TABLE[500] = {485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,   485 ,
		490 ,   490 ,   490 ,   490 ,   490 ,   490 ,   490 ,   490 ,   490 ,   490 ,
		500 ,   500 ,   500 ,   500 ,   500 ,   500 ,   500 ,   500 ,   500 ,   500 ,
		510 ,   510 ,   510 ,   510 ,   510 ,   510 ,   510 ,   510 ,   510 ,   510 ,
		520 ,   520 ,   520 ,   520 ,   520 ,   520 ,   520 ,   520 ,   520 ,   520 ,
		530 ,   530 ,   530 ,   530 ,   530 ,   530 ,   530 ,   530 ,   530 ,   530 ,
		540 ,   540 ,   540 ,   540 ,   540 ,   540 ,   540 ,   540 ,   540 ,   540 ,
		550 ,   550 ,   550 ,   550 ,   550 ,   560 ,   560 ,   560 ,   560 ,   560 ,
		570 ,   570 ,   570 ,   570 ,   570 ,   580 ,   580 ,   580 ,   580 ,   580 ,
		585 ,   585,   585,   585,   585,   595 ,   595 ,   595 ,   595 ,   595 ,
		625,   625,   625,   625,   625,   630,   630,   630,   630,   630,
		640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,
		640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,
		640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,   640 ,
		650,   650,   650,   650,   650,   650,   650,   650,   650,   650,
		675 ,   675 ,   675 ,   675 ,   675 ,   675 ,   675 ,   675 ,   675 ,   675 ,
		680 ,   680 ,   680 ,   680 ,   680 ,   690 ,   690 ,   690 ,   690 ,   690 ,
		700 ,   700 ,   700 ,   700 ,   700 ,   700 ,   700 ,   710 ,   710 ,   710 ,
		720 ,   720 ,   720 ,   720 ,   720 ,   730 ,   730 ,   730 ,   730 ,   730 ,
		740 ,   740 ,   740 ,   740 ,   740 ,   740 ,   740 ,   740 ,   740 ,   740 ,
		750 ,   750 ,   750 ,   750 ,   750 ,   750 ,   750 ,   750 ,   750 ,   750 ,
		760 ,   760 ,   760 ,   760 ,   760 ,   760 ,   760 ,   760 ,   760 ,   760 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,
		770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770 ,   770};   // 49

volatile uint8 RUNMODE = IDLE;

volatile uint32 RUN_INIT_COUNT = 0;
volatile uint8 RUN_INIT_FLAG = 0;

const uint16 MAX_VALUE[7] = {1000, 1200, 1400, 1500, 1400, 1200, 1000};
const uint16 SPEED_TABLE[7] = {500, 600, 700, 750, 700, 600, 500};

volatile uint8 DIRECTION_BEFORE = CENTER;
volatile uint32 DIRECTION_COUNT = 0;
volatile uint8 DIRECTION_NOW = CENTER;
volatile uint8 DIRECTION_START_FLAG = 0;
volatile uint8 DIRECTION_END_FLAG = 0;


volatile uint8 SENSOR_STATUS[6] = {OFF, OFF, OFF, OFF, OFF, OFF};
volatile uint32 SENSOR_DETECT_CNT = 0;
volatile uint8 SENSOR_FLAG[6] = {OFF, OFF, OFF, OFF, OFF, OFF};
volatile uint8 SENSOR_FLAG_BEFORE[6] = {OFF, OFF, OFF, OFF, OFF, OFF};

volatile uint32 SENSOR_TEST_CNT = 0;

volatile uint16 AVOID_DISTANCE[3] = {9999,9999,9999};

volatile const uint8 AVOID_INDEX[3] = {3, 4, 11};

volatile uint8 AVOID_STATUS	= AVOID_IDLE;

volatile uint32 AVOID_CHECKING_CNT = 0;

volatile uint32 AVOID_TRUN_GAP	   = 0;

volatile uint8 AVOID_RECOVER_FLAG  = 0;
volatile uint8 AVOID_RECOVER_FLAG_BEFORE = 0;

const uint16 STOP_MAX_VALUE[4] = {10, 800, 800, 1100};
const uint16 STOP_SPEED_TABLE[4] = {0, 200, 400, 550};

volatile int PIXEL_INDEX = 0;
volatile int PRINT_STATUS = 0;

volatile int SERVO_TEST = 640;

void FrontControl(uint16 Angle){


	Pwm_StepDutyUpdate(IfxGtm_TOM1_0_TOUT32_P33_10_OUT,Angle);
}


void CarRuning(uint16 Speed,uint16 Direction){

	Pwm_MotorDutyAndDirectionControl(Speed, Direction);

}

void ServoControl()
{
	FrontControl(SERVO_TABLE[LINE_NUM]);

}

void Gen_Pulse(uint16 SI_period, uint8 STATUS)
{
	int i,j,k;

	uint8 tmp;
	if(initSICount == 0)
	{
		P00_OUT.B.P7 = HIGH;
		P00_OUT.B.P8 = HIGH;
	}
	else
	{
		P00_OUT.B.P7 = !P00_OUT.B.P7;
		P00_OUT.B.P8 = !P00_OUT.B.P8;

	}

	if(initSICount == (2*SI_period + 1))
	{
		P00_OUT.B.P5 = P00_OUT.B.P6 = 1;

		LineCalculation(CAM1);
		LineCalculation(CAM2);

		//GetRunningLine();


#if CAM_1_DEBUG
		for(i = 44; i<= 83; i++)
		{
			if(Get_CaliVaule(CAM_CHECK & 0xFF,i) > CAM_THRESHOLD)
				tmp = 1;
			else tmp = 0;
			UartChar(tmp + '0');
			Uart_Tx(1);
		}

		EnterLine();
#endif
#if CAM_RAW_DEBUG
		for(i = 60; i<= 61; i++)
		{
			ClearUartTx();
			UartStoreADC(CAM_Data[CAM_CHECK].CAM_Raw[i] & 0xFFF);
			Uart_Tx(5);
		}

		EnterLine();
#endif
#if CAM_CALIB_DEBUG
		for(i = 60; i<= 61; i++)
		{
			ClearUartTx();
			UartStoreADC(Get_CaliVaule(CAM_CHECK & 0xFF,i) & 0xFFF);
			Uart_Tx(5);
		}

		UartChar((RUNMODE & 0xFF) + '0');
		Uart_Tx(1);

		EnterLine();
#endif


	}
	else if(initSICount == (2*SI_period + 2))
	{
		P00_OUT.B.P5 = P00_OUT.B.P6 = 0;
		initSICount = -1;
		Camera_flag = 1;

	}
	else
	{

		if((initSICount % 2) == 1)
		{
			if(initSICount/2 < 128)
			{
				Test_VadcAutoScan(IfxVadc_GroupId_1);

				CAM_Data[CAM1].CAM_Raw[initSICount/2] = 4095 - (Get_VadcValue(IfxVadc_GroupId_1, Cam_Index[0]) & 0xFFF);
				CAM_Data[CAM2].CAM_Raw[initSICount/2] = 4095 - (Get_VadcValue(IfxVadc_GroupId_1, Cam_Index[1]) & 0xFFF);

			}
		}
	}
	initSICount++;
}

void EncoderCheck(void)
{
	boolean value = IfxPort_getPinState(&MODULE_P21,5 );

	if(encoder_before == 0 && value == 1)
	{
		encoder_cnt++;
	}
	encoder_before = value;

}

void SensorCheck()
{
	int i;
	uint16 tmpvalue = 0;
	uint8 tmpCnt = 0;
	Test_VadcAutoScan(IfxVadc_GroupId_0);
	for(i = 0 ; i<6; i++)
	{
		tmpvalue = Get_IRCalibValue(i);
		if(tmpvalue > 75) SENSOR_FLAG[i] = ON;
		else SENSOR_FLAG[i] = OFF;

		if(SENSOR_FLAG[i] != SENSOR_FLAG_BEFORE[i] && (SENSOR_FLAG[i] == ON))
		{
			SENSOR_STATUS[i] = ON;
			SENSOR_DETECT_CNT = 0;
		}
		SENSOR_FLAG_BEFORE[i] = SENSOR_FLAG[i];

		if(SENSOR_STATUS[i] == ON)
			tmpCnt++;
	}

	if(tmpCnt >= 4)
	{
		if(RUNNING_STATUS == RUN_LIMIT_START && AVOID_STATUS == AVOID_RUN2)
			AVOID_STATUS = AVOID_RECOVER_R;
		else
			RUNNING_STATUS++;
		for(i = 0 ; i<6; i++)
		{
			SENSOR_STATUS[i] = OFF;
		}
	}
}

void AvoidSensorCheck()
{
	int i;
	uint16 tmpvalue = 0;
	uint8 tmpCnt = 0;
	Test_VadcAutoScan(IfxVadc_GroupId_0);
	for(i = 0 ; i<6; i++)
	{
		tmpvalue = Get_IRCalibValue(i);
		if(tmpvalue > 75) SENSOR_FLAG[i] = ON;
		else SENSOR_FLAG[i] = OFF;

		if(SENSOR_FLAG[i] != SENSOR_FLAG_BEFORE[i] && (SENSOR_FLAG[i] == ON))
		{
			SENSOR_STATUS[i] = ON;
			SENSOR_DETECT_CNT = 0;
		}
		SENSOR_FLAG_BEFORE[i] = SENSOR_FLAG[i];

		if(SENSOR_STATUS[i] == ON)
			tmpCnt++;
	}

	if(tmpCnt >= 6)
	{
		AVOID_TRUN_GAP = 0;
		if(AVOID_STATUS == AVOID_MOVE_L)
			AVOID_STATUS = AVOID_RUN2;
		else if(AVOID_STATUS == AVOID_MOVE_R)
			AVOID_STATUS = AVOID_RUN1;
		else if(AVOID_STATUS == AVOID_RECOVER_R)
			AVOID_STATUS = AVOID_RECOVER_RUN;
		for(i = 0 ; i<6; i++)
		{
			SENSOR_STATUS[i] = OFF;
		}
	}

}

void DistanceCheck()
{
	int tmpDistance;
	int i=0;
	AVOID_DISTANCE[FRONT_D_1] = Get_VadcValue(IfxVadc_GroupId_1, AVOID_INDEX[FRONT_D_1]);
	AVOID_DISTANCE[FRONT_D_2] = Get_VadcValue(IfxVadc_GroupId_1, AVOID_INDEX[FRONT_D_2]);

	if(AVOID_STATUS == AVOID_RUN1 || AVOID_STATUS == AVOID_IDLE)
	{
		tmpDistance = (AVOID_DISTANCE[FRONT_D_1] + AVOID_DISTANCE[FRONT_D_2]) / 2;
		if(tmpDistance > AVOID_FRONT_DISTANCE)
		{
			AVOID_STATUS = AVOID_MOVE_L;
		}
	}

	if(AVOID_STATUS == AVOID_RUN2)
	{
		tmpDistance = (AVOID_DISTANCE[FRONT_D_1] + AVOID_DISTANCE[FRONT_D_2]) / 2;
		if(tmpDistance > AVOID_FRONT_DISTANCE)
		{
			AVOID_STATUS = AVOID_MOVE_R;
		}
	}
#if DISTANCE_DEBUG
	for(i=0; i<3; i++)
	{
		ClearUartTx();
		UartStoreADC(AVOID_DISTANCE[i] &0xFFF);
		Uart_Tx(5);
	}
	EnterLine();
#endif

	Infra_Red_Direction();
}

void LineCheck()
{
	if(RUNNING_STATUS != RUN_LIMIT_START)
	{
		LINE_NUM = (CAM1_RAW_LINE + CAM2_RAW_LINE) / 2;


		if(LINE_NUM <= 169)
			DIRECTION_NOW = LEFT2;
		else if(LINE_NUM <= 199)
			DIRECTION_NOW = LEFT1;
		else if(LINE_NUM <= 224)
			DIRECTION_NOW = LEFT;
		else if(LINE_NUM <= 284)
			DIRECTION_NOW = CENTER;
		else if(LINE_NUM <= 319)
			DIRECTION_NOW = RIGHT;
		else if(LINE_NUM <= 339)
			DIRECTION_NOW = RIGHT1;
		else
			DIRECTION_NOW = RIGHT2;

		if(DIRECTION_NOW != DIRECTION_BEFORE)
		{
			DIRECTION_COUNT = 0;
		}

		if(DIRECTION_COUNT > 10000)
			LINE_STATUS = DIRECTION_NOW;

		DIRECTION_BEFORE = DIRECTION_NOW;
		HeadDirection(LINE_STATUS);
	}
}

void AvoidLineCheck()
{
	if(AVOID_STATUS == AVOID_IDLE)
		LINE_NUM = (CAM1_RAW_LINE + CAM2_RAW_LINE) / 2;
	else if(AVOID_STATUS == AVOID_MOVE_L)
		LINE_NUM = 1;
	else if(AVOID_STATUS == AVOID_RUN2)
	{
		if(AVOID_TRUN_GAP < 700)
		{
			AVOID_TRUN_GAP++;
			LINE_NUM = 310;
		}
		else
		{
			LINE_NUM = (CAM1_RAW_LINE + CAM2_RAW_LINE) / 2;
		}
	}
	else if(AVOID_STATUS == AVOID_MOVE_R || AVOID_STATUS == AVOID_RECOVER_R)
		LINE_NUM = 490;
	else if(AVOID_STATUS == AVOID_RUN1)
	{
		if(AVOID_TRUN_GAP < 700)
		{
			AVOID_TRUN_GAP++;
			LINE_NUM = 178;
		}
		else
		{
			LINE_NUM = (CAM1_RAW_LINE + CAM2_RAW_LINE) / 2;
		}
	}
	else if(AVOID_STATUS == AVOID_RECOVER_RUN)
	{
		if(AVOID_TRUN_GAP < 700)
		{
			AVOID_TRUN_GAP++;
			LINE_NUM = 178;
		}
		else RUNMODE = RUN_RESUME;
	}
	else
	{

		LINE_NUM = (CAM1_RAW_LINE + CAM2_RAW_LINE) / 2;
	}

	HeadDirection(100); // OFF
}

void core0_main (void)
{
    __enable ();
    /*
     * !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
     * Enable the watchdog in the demo if it is required and also service the watchdog periodically
     * */
    IfxScuWdt_disableCpuWatchdog (IfxScuWdt_getCpuWatchdogPassword ());
    IfxScuWdt_disableSafetyWatchdog (IfxScuWdt_getSafetyWatchdogPassword ());

    Test_ModuleInit();

    while (1)
    {

    	inittest=0;
    	initStartCount = 0;

    	//if(RUNMODE == RUN)
    	//{
        	EncoderCheck();

    		LineCheck();

    	//}

    }

}

void Timer10us_Initialization(void)
{
    volatile float       stm_freq;
    Ifx_STM             *stm = &MODULE_STM0;
    IfxStm_CompareConfig stmCompareConfig;

    /* suspend by debugger enabled */
    IfxStm_enableOcdsSuspend(stm);
    /* get current STM frequency : debug purpose only*/
    stm_freq = IfxScuCcu_getStmFrequency();
    /* constructor of configuration */
    IfxStm_initCompareConfig(&stmCompareConfig);
	stmCompareConfig.triggerPriority = ISR_PRIORITY_STM;
	stmCompareConfig.ticks = 1000;
	stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;
    /* Now Compare functionality is initialized */
    IfxStm_initCompare(stm, &stmCompareConfig);

} // End of TaskScheduler_Initialization()

//*********************************************************************************************
// @Function	 	void UsrIsr_Stm_0(void)
// @Description   	STM0 Interrupt for system tick generation
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
IFX_INTERRUPT (Timer10us_Isr, 0, ISR_PRIORITY_STM);
void Timer10us_Isr(void)
{
    Ifx_STM *stm = &MODULE_STM0;
    int i, tmpAvg;
    //HeadDirection(LEFT);
    /* Set next 1ms scheduler tick alarm */

    IfxStm_updateCompare(stm, IfxStm_Comparator_0, IfxStm_getLower(stm) + 1000);
    //EncoderCheck();

    DIRECTION_COUNT++;
    if(DIRECTION_COUNT>=10000)
    {
    	DIRECTION_COUNT = 0;
    }

    if(IfxPort_getPinState(&MODULE_P22,2 ) == 0)
    {

    	SWITCH_CNT[0]++;
    	if(SWITCH_CNT[0] > 50)
    		SWITCH_FLAG[0] = 1;
    	else
    		SWITCH_FLAG[0] = 0;
    }
    else SWITCH_FLAG[0] = 0;

    if(IfxPort_getPinState(&MODULE_P22,0 ) == 0)
	{
    	SWITCH_CNT[1]++;
    	if(SWITCH_CNT[1] > 50)
    		SWITCH_FLAG[1] = 1;
    	else
    		SWITCH_FLAG[1] = 0;
	}
    else SWITCH_FLAG[1] = 0;

    if(IfxPort_getPinState(&MODULE_P22,1 ) == 0)
	{
    	SWITCH_CNT[2]++;
    	if(SWITCH_CNT[2] > 50)
    		SWITCH_FLAG[2] = 1;
    	else
    		SWITCH_FLAG[2] = 0;
	}
    else SWITCH_FLAG[2] = 0;

    if(SWITCH_FLAG[0] != SWITCH_FLAG_BEFORE[0] && SWITCH_FLAG[0] == 1)
    {
    	RUNMODE = CALIB_START;

    	P13_OUT.B.P0 = LOW;
    	P13_OUT.B.P1 = HIGH;
    	P13_OUT.B.P2 = HIGH;

    	//SET_SPEED(500);
    	SERVO_TEST -= 5;

    }
    else if(SWITCH_FLAG[1] != SWITCH_FLAG_BEFORE[1] && SWITCH_FLAG[1] == 1)
    {

    	RUNMODE = CALIB_STOP;
    	CAM_CHECK = CAM2;
    	P13_OUT.B.P0 = HIGH;
    	P13_OUT.B.P1 = LOW;
    	P13_OUT.B.P2 = HIGH;
    	SERVO_TEST = 640;
    	//SET_SPEED(800);
    }
    else if(SWITCH_FLAG[2] != SWITCH_FLAG_BEFORE[2] && SWITCH_FLAG[2] == 1)
    {

    	RUNMODE = RUN;
    	CAM_CHECK = CAM1;
    	P13_OUT.B.P0 = HIGH;
    	P13_OUT.B.P1 = HIGH;
    	P13_OUT.B.P2 = LOW;

    	SERVO_TEST += 5;
    	SET_SPEED(SPEED_TABLE[LINE_STATUS]);
    }

    SWITCH_FLAG_BEFORE[0] = SWITCH_FLAG[0];
    SWITCH_FLAG_BEFORE[1] = SWITCH_FLAG[1];
    SWITCH_FLAG_BEFORE[2] = SWITCH_FLAG[2];



    if(RUNMODE == CALIB_START)
    {
    	Sensor_Calibration();
    }
    else if(RUNMODE == RUN)
    {

    	SENSOR_DETECT_CNT++;
    	if(SENSOR_DETECT_CNT >= 200000)
    	{
    		SENSOR_DETECT_CNT = 0;
    		for(i = 0; i<6;i++)
    			SENSOR_STATUS[i] = OFF;
    	}


    	if(RUNNING_STATUS == RUN_IDE || RUNNING_STATUS == RUN_START || RUNNING_STATUS == RUN_RESUME)
    	{
			RUN_INIT_COUNT++;

			if(RUN_INIT_COUNT > 100000)
			{
				RUN_INIT_COUNT = 0;
				RUN_INIT_FLAG = 1;
			}

			if(RUN_INIT_FLAG == 1)
			{

				SET_MAX_SPEED(MAX_VALUE[LINE_STATUS]);
				SET_SPEED(SPEED_TABLE[LINE_STATUS]);
			}
    	}
    	else if(RUNNING_STATUS == RUN_LIMIT_START)
    	{
			SET_MAX_SPEED(AVOID_MAX);
			SET_SPEED(AVOID_SPEED);
			AVOID_CHECKING_CNT++;
			if(AVOID_CHECKING_CNT >= 100)
			{
				AVOID_CHECKING_CNT = 0;
				DistanceCheck();
				AvoidLineCheck();
			}

    	}
    	else
    	{
    		Distance_sensor();
    		tmpAvg = (AVOID_DISTANCE[0] + AVOID_DISTANCE[1])/2;
    		if(tmpAvg <= 900)
    		{
    			SET_MAX_SPEED(1100);
    			SET_SPEED(650);
    		}
    		else if(tmpAvg <= 1200)
    		{
    			SET_MAX_SPEED(1000);
    			SET_SPEED(500);
    		}
    		else if(tmpAvg <= 2000)
			{
				SET_MAX_SPEED(600);
				SET_SPEED(300);
			}
    		else
    		{
    			SET_MAX_SPEED(10);
    			SET_SPEED(0);
    		}
    	}
    }

    CLKCount++;
    if(CLKCount >= 5)
    {
		CLKCount = 0;
		Gen_Pulse(128, RUNMODE);
    }


    Count1ms++;
	if(Count1ms >= 100)
	{
		Count1ms = 0;

		if(RUNMODE == RUN || RUNMODE == CALIB_STOP)
		{
		    ServoControl();
		}

		if(RUNMODE == RUN)
		{

	    	SENSOR_TEST_CNT++;

	    	if(SENSOR_TEST_CNT >= 10)
			{
	    		if(AVOID_STATUS == AVOID_MOVE_L || AVOID_STATUS == AVOID_MOVE_R)
					AvoidSensorCheck();
	    		else
	    			SensorCheck();
#if MODE_DEBUG
				SENSOR_TEST_CNT = 0;
				ClearUartTx();
				UartStoreADC(RUNNING_STATUS &0xFFFF);
				Uart_Tx(5);
				EnterLine();
#endif
			}
		}
		if(IfxPort_getPinState(&MODULE_P22,2 ) == 1)
		{
			SWITCH_CNT[0] = 0;
		}
		else if(IfxPort_getPinState(&MODULE_P22,0 ) == 1)
		{
			SWITCH_CNT[1] = 0;
		}
		else if(IfxPort_getPinState(&MODULE_P22,1 ) == 1)
		{
			SWITCH_CNT[2] = 0;
		}

#if CAM_ALL_DEBUG
		if(RUNMODE == CALIB_STOP)
		{
			ClearUartTx();
			if(PRINT_STATUS == 0)
				UartStoreADC(CAM_Data[CAM1].CAM_Raw[PIXEL_INDEX]&0xFFF);
			else if(PRINT_STATUS == 1)
				UartStoreADC(CAM_Data[CAM2].CAM_Raw[PIXEL_INDEX]&0xFFF);

			Uart_Tx(5);

			PIXEL_INDEX++;
			if(PIXEL_INDEX >= 128)
			{
				EnterLine();
				EnterLine();
				PIXEL_INDEX = 0;
				if(PRINT_STATUS == 1)
				{
					RUNMODE = IDLE;
					PRINT_STATUS = 0;
				}
				else
					PRINT_STATUS++;
			}
		}
#endif

	}

    // Operate Confirm
    test_count++;
    if(test_count >= 10000)
    {
    	test_count = 0;

    	P13_OUT.B.P3 = !P13_OUT.B.P3;
    }

    __enable();


}

void HeadDirection(int x)
{

	if (x <= LEFT)
	{
		 P02_OUT.B.P0 = 0;  // Left LED ON of First line
		 P02_OUT.B.P1 = 0;
		 P02_OUT.B.P2 = 1;
	}
	else if (x >= RIGHT)
	{
		 P02_OUT.B.P0 = 1;  // Right LED ON of First line
	     P02_OUT.B.P1 = 0;
		 P02_OUT.B.P2 = 0;
	}
	else if (x == CENTER)
	{
		 P02_OUT.B.P0 = 0;  // Center LED ON of First line
		 P02_OUT.B.P1 = 1;
		 P02_OUT.B.P2 = 0;
	}
	else
	{
		 P02_OUT.B.P0 = 0;
		 P02_OUT.B.P1 = 0;
		 P02_OUT.B.P2 = 0;
	}

}

void Distance_sensor(void)
{
   int i = 0;
   AVOID_DISTANCE[0] = Get_VadcValue(IfxVadc_GroupId_1, AVOID_INDEX[FRONT_D_1]);
   AVOID_DISTANCE[1] = Get_VadcValue(IfxVadc_GroupId_1, AVOID_INDEX[FRONT_D_2]);

#if DISTANCE_DEBUG
   for(i = 0; i < 2; i++)
   {
      ClearUartTx();
      UartStoreADC(Distance[i] & 0xFFF);
      Uart_Tx(5);
   }
#endif
}

void Infra_Red_Direction()
{
	if (AVOID_DISTANCE[FRONT_D_1] > AVOID_FRONT_DISTANCE)
		 P02_OUT.B.P5 = HIGH;
	else P02_OUT.B.P5 = LOW;

	if (AVOID_DISTANCE[FRONT_D_2] > AVOID_FRONT_DISTANCE)
		 P02_OUT.B.P4 = HIGH;
	else P02_OUT.B.P4 = LOW;

	if (AVOID_DISTANCE[RIGHT_D] > AVOID_RIGHT_DISTANCE)
		 P02_OUT.B.P3 = 1;
	else P02_OUT.B.P3 = 0;

}

void LineCalculation(int Cam_No)
{
	uint32 LINE_INFO[50], Weight_Sum = 0, Sum = 0;

	Weight_Total = 0, Sum_Total = 0;
	int i, startX = 39, stopX = 88;
	uint32 tmpmin = 9999;
	uint8 EMPTY_AREA = 1;
	int CT1, CT2;
	// BLUR
	for(i = startX; i<= stopX; i++)
	{
		if(i != startX)
			LINE_INFO[i-startX] = (LINE_INFO[i-startX - 1] + (CAM_Data[Cam_No].CAM_Raw[i]&0xFFF))/2;
		else
			LINE_INFO[i-startX] = (CAM_Data[Cam_No].CAM_Raw[i]&0xFFF);

		if(tmpmin > LINE_INFO[i - startX])
			tmpmin = LINE_INFO[i - startX];
	}

	// subtract min
	for(i = 0; i< 50; i++)
	{
		LINE_INFO[i] = LINE_INFO[i] - tmpmin;
		if(LINE_INFO[i] > 900)
			EMPTY_AREA = 0;
	}
	// CT
	if(EMPTY_AREA == 0)
	{
		CAM_CT_RESULT[Cam_No][0] = LINE_INFO[0];
		for(i = 1; i< 49; i++)
		{
			if(LINE_INFO[i-1] > LINE_INFO[i]) CT1 = 1;
			else CT1 = 0;
			if(LINE_INFO[i+1] > LINE_INFO[i]) CT2 = 1;
			else CT2 = 0;

			if(CT1 ^ CT2)
				CAM_CT_RESULT[Cam_No][i] = LINE_INFO[i] * 2;
			else
				CAM_CT_RESULT[Cam_No][i] = LINE_INFO[i] * 1;
		}
		CAM_CT_RESULT[Cam_No][49] = LINE_INFO[49];

		for(i = 0 ; i< 50; i++)
		{
			Weight_Sum += CAM_CT_RESULT[Cam_No][i] * (i+1);
			Sum += CAM_CT_RESULT[Cam_No][i];
		}

		if(Cam_No == CAM1)
			CAM1_RAW_LINE = (Weight_Sum * 10 ) / Sum;
		else
			CAM2_RAW_LINE = (Weight_Sum * 10) / Sum;
	}
}


