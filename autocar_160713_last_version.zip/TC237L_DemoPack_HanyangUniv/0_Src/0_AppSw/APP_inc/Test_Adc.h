/*
 * Test_Adc.h
 *
 *  Created on: 2015. 3. 26.
 *      Author: kimwayne
 */

#ifndef TEST_ADC_H_
#define TEST_ADC_H_

/******************************************************************************/
/*----------------------------------Includes----------------------------------*/
/******************************************************************************/
#include <Vadc/Std/IfxVadc.h>
#include <Vadc/Adc/IfxVadc_Adc.h>

/******************************************************************************/
/*-----------------------------------Macros-----------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*--------------------------------Enumerations--------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*-----------------------------Data Structures--------------------------------*/
/******************************************************************************/
#define MaxChNum            (12U)
#define MaxModuleNum        (2U)

#define IRSeonSorNum		(6U)
#define CamNum				(2U)

typedef struct
{
    IfxVadc_Adc vadc; /* VADC handle */
    IfxVadc_Adc_Group adcGroup[MaxModuleNum];
} App_VadcAutoScan;



#define ON  1
#define OFF 0

/******************************************************************************/
/*------------------------------Global variables------------------------------*/
/******************************************************************************/
IFX_EXTERN App_VadcAutoScan VadcAutoScan;
IFX_EXTERN const uint8 adc_ch_cfg[][MaxChNum];
IFX_EXTERN uint16  	Adc_Max[IRSeonSorNum];
IFX_EXTERN uint16  	Adc_Min[IRSeonSorNum];
IFX_EXTERN uint8   	Adc_Index[IRSeonSorNum];
IFX_EXTERN uint8	Cam_Index[CamNum];

/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/

IFX_EXTERN void Test_VadcAutoScan(IfxVadc_GroupId GroupId);
IFX_EXTERN uint32 Get_VadcValue(IfxVadc_GroupId GroupId, IfxVadc_ChannelId ChanelId);
IFX_EXTERN void Sensor_Calibration();
IFX_EXTERN uint16 Get_IRCalibValue(uint8 IrId);
#endif /* TEST_ADC_H_ */
